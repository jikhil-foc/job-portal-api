export const Jwt = {
    secret: '!!@##$$$%%%%%%$$###'
}